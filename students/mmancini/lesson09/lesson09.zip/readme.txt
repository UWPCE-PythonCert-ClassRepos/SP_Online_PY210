
Notes.
	1. canned files support regression tests as new versions of the mailroom app are released.

	2. pytest_results.txt contains the pytest test suite result for major mailroom threads of execution.

